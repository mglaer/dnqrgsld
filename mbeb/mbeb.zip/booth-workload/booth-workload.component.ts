import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booth-workload',
  templateUrl: './booth-workload.component.html',
  styleUrls: ['./booth-workload.component.css']
})
export class BoothWorkloadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
