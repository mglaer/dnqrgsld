import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-mbeb',
  templateUrl: './project-mbeb.component.html',
  styleUrls: ['./project-mbeb.component.css']
})
export class ProjectMbebComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
