import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { VCalculation } from 'src/app/model/structures';
import { MasterService } from 'src/app/services/master.service';

@Component({
  selector: 'app-calc-view',
  templateUrl: './calc-view.component.html',
  styleUrls: ['./calc-view.component.css']
})
export class CalcViewComponent implements OnInit {
  public ID!: number;
  public parent_id!: number;
  calc_form: FormGroup;
  calculation = <VCalculation>{};
  //
  records: any[] = [];
  headers: any[] = [];
  //-------------------------------
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private formBuilder: FormBuilder,
    private service: MasterService
  ) {
    this.calc_form = this.formBuilder.group(
      {
        ID: new FormControl(''),
        ShortTitle: new FormControl(''),
        Description: new FormControl(''),
        Module: new FormControl(''),
        InOutFile: new FormControl(''),
        Status: new FormControl(''),
        Path: new FormControl('')
      }
    );
    //
  }

  ngOnInit(): void {
    this.route.params.subscribe((params: Params) => {
      this.ID = params['id'];
      this.parent_id = params['parent_id'];
      /*if (params['id'] != undefined) {
        this.ID = JSON.parse(params['id']);
      }*/
      this.InitForm();
    });
  }
  //--------------------------------------------------------
  InitForm() {
    //---
    if (this.ID != undefined) {
      this.service.RedKeyGetCalculation_by_ID(this.ID).subscribe((result: any) => {
        if (result.data != null) {
          this.calculation = result.data[0];
          this.CreateCsvTable();
          this.calc_form.setValue(
            {
              ID: this.calculation.ID,
              ShortTitle: this.calculation.ShortTitle,
              Description: this.calculation.Description,
              Module: this.calculation.Module,
              InOutFile: this.calculation.InOutFile,
              Status: this.calculation.Status,
              Path: this.calculation.Path
            }
          );
        }
      });
    }

  }
  //------------------------------------------------------------------------------
  CreateCsvTable() {
    //
    let csvToRowArray = this.calculation.InOutFile.split("\n");
    this.headers = csvToRowArray[0].split(",").map((e: any) => e.trim());
    this.records = csvToRowArray.slice(1).map((row: any) => row.split(","));
    //            
  }
  //----------------------------------------------------
  onSubmit(): void {

  }
  //--------------------------------------------------------
  exit() {
    this.router.navigate(['home/calculation_list', { id: this.parent_id }]);
  }
}
